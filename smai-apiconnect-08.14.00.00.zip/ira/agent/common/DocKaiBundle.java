/*
 COPYRIGHT_COMMENT_TAG_BEGIN
 IBM Confidential
 OCO Source Materials
 5724-C04
 
 Copyright IBM Corp. 2005, 2011
 The source code for this program is not published or otherwise
 divested of its trade secrets, irrespective of what has
 been deposited with the U.S. Copyright Office.
 COPYRIGHT_COMMENT_TAG_END
 */
//***************************************************************************
//                                                                          *
// Unpublished Copyright (c) 1998, 2004 Candle Corporation.                 *
//                                                                          *
// All rights reserved.  International copyright secured.                   *
// USE PERMISSIBLE UNDER LICENSE ONLY.  This software may be                *
// protected by one or more United States and/or international              *
// patents or pending patent applications.                                  *
//                                                                          *
//***************************************************************************

/**
 * Resources
 * NLS_MESSAGEFORMAT_NONE (CHKPII flag indicating that the text is not 
 *                         processed by Java MessageFormat class)
 */

//***************************************************************************
//                >>>>  M A I N T E N A N C E    L O G  <<<<                *
//***************************************************************************
//  $Date: August 15, 2017 1:02:28 PM EDT $
//  $Revision: 1.0 $
//
//***************************************************************************

// NLS_ENCODING=UTF-8
package candle.kai.resources;

import candle.kjr.resource.*;
import candle.kjr.util.*;
import java.util.*;
import java.lang.reflect.Method;

/**
 * <code>DocKaiBundle</code> contains Kai ODI definitions for NLS.
 *
 */

public class DocKaiBundle extends ResourceBundle implements Versioned
{
  private static final long serialVersionUID = 1L;

  private static final String BUNDLE_ID       = "dockai";
  private static final String BUNDLE_NAME     = "candle.kai.resources.DocKaiBundle";

  private static final IntegerVersion version = new IntegerVersion(100);

  // public Object[][] getContents() - needed for CHKPII tool
  
public Object[][] _oM1()
{
Object[][] contents = 
{
        {"%IBM.KAI",                                      "APIConnect"},
};
return contents;
}

public Object[][] _oM2()
{
Object[][] contents = 
{
        {"%IBM.KAIMGT",                                   "APIC Mgmt Server"},
};
return contents;
}

public Object[][] _oM3()
{
Object[][] contents = 
{
        {"TABLE.KAIMGTDS.OBJECT",                         "KAI APIC MGMT SERVER NODES"},
        {"KAIMGTDS.ORIGINNODE",                           "Node"},

        {"KAIMGTDS.TIMESTAMP",                            "Timestamp"},

        {"KAIMGTDS.SN_MSN",                               "Subnode MSN"},

        {"KAIMGTDS.SN_AFFIN",                             "Subnode Affinity"},

        {"KAIMGTDS.SN_TYPE",                              "Subnode Type"},

        {"KAIMGTDS.SN_RES",                               "Subnode Resource Name"},

        {"KAIMGTDS.SN_VER",                               "Subnode Version"},

};
return contents;
}

public Object[][] _oM4()
{
Object[][] contents = 
{
        {"TABLE.KAIPOBJST.OBJECT",                        "KAI PERFORMANCE OBJECT STATUS"},
        {"KAIPOBJST.ORIGINNODE",                          "Node"},

        {"KAIPOBJST.TIMESTAMP",                           "Timestamp"},

        {"KAIPOBJST.ATTRGRP",                             "Query Name"},

        {"KAIPOBJST.OBJNAME",                             "Object Name"},

        {"KAIPOBJST.OBJTYPE",                             "Object Type"},
        {"KAIPOBJST.OBJTYPE.ENUM.0",                      "WMI"},
        {"KAIPOBJST.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"KAIPOBJST.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"KAIPOBJST.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"KAIPOBJST.OBJTYPE.ENUM.12",                     "JDBC"},
        {"KAIPOBJST.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"KAIPOBJST.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"KAIPOBJST.OBJTYPE.ENUM.15",                     "FILTER"},
        {"KAIPOBJST.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"KAIPOBJST.OBJTYPE.ENUM.17",                     "PING"},
        {"KAIPOBJST.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"KAIPOBJST.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"KAIPOBJST.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"KAIPOBJST.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"KAIPOBJST.OBJTYPE.ENUM.3",                      "JMX"},
        {"KAIPOBJST.OBJTYPE.ENUM.4",                      "SNMP"},
        {"KAIPOBJST.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"KAIPOBJST.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"KAIPOBJST.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"KAIPOBJST.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"KAIPOBJST.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"KAIPOBJST.OBJSTTS",                             "Object Status"},
        {"KAIPOBJST.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"KAIPOBJST.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"KAIPOBJST.ERRCODE",                             "Error Code"},
        {"KAIPOBJST.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"KAIPOBJST.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"KAIPOBJST.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"KAIPOBJST.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"KAIPOBJST.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"KAIPOBJST.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"KAIPOBJST.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"KAIPOBJST.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"KAIPOBJST.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"KAIPOBJST.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"KAIPOBJST.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"KAIPOBJST.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"KAIPOBJST.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"KAIPOBJST.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"KAIPOBJST.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"KAIPOBJST.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"KAIPOBJST.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"KAIPOBJST.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"KAIPOBJST.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"KAIPOBJST.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"KAIPOBJST.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"KAIPOBJST.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"KAIPOBJST.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"KAIPOBJST.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"KAIPOBJST.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"KAIPOBJST.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"KAIPOBJST.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"KAIPOBJST.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"KAIPOBJST.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"KAIPOBJST.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"KAIPOBJST.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"KAIPOBJST.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"KAIPOBJST.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"KAIPOBJST.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"KAIPOBJST.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"KAIPOBJST.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"KAIPOBJST.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"KAIPOBJST.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"KAIPOBJST.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"KAIPOBJST.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"KAIPOBJST.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"KAIPOBJST.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"KAIPOBJST.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"KAIPOBJST.ERRCODE.ENUM.66",                     "DISABLED"},
        {"KAIPOBJST.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"KAIPOBJST.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"KAIPOBJST.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"KAIPOBJST.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"KAIPOBJST.ERRCODE.ENUM.70",                     "ICMP SOCKETS FAILED"},
        {"KAIPOBJST.ERRCODE.ENUM.71",                     "DUPLICATE CONF FILE"},
        {"KAIPOBJST.ERRCODE.ENUM.72",                     "DELETED CONFIGURATION"},
        {"KAIPOBJST.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"KAIPOBJST.COLSTRT",                             "Last Collection Start"},
        {"KAIPOBJST.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAIPOBJST.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAIPOBJST.COLFINI",                             "Last Collection Finished"},
        {"KAIPOBJST.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAIPOBJST.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAIPOBJST.COLDURA",                             "Last Collection Duration"},

        {"KAIPOBJST.COLAVGD",                             "Average Collection Duration"},
        {"KAIPOBJST.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"KAIPOBJST.REFRINT",                             "Refresh Interval"},

        {"KAIPOBJST.NUMCOLL",                             "Number of Collections"},

        {"KAIPOBJST.CACHEHT",                             "Cache Hits"},

        {"KAIPOBJST.CACHEMS",                             "Cache Misses"},

        {"KAIPOBJST.CACHPCT",                             "Cache Hit Percent"},

        {"KAIPOBJST.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

public Object[][] _oM5()
{
Object[][] contents = 
{
        {"TABLE.KAITHPLST.OBJECT",                        "KAI THREAD POOL STATUS"},
        {"KAITHPLST.ORIGINNODE",                          "Node"},

        {"KAITHPLST.TIMESTAMP",                           "Timestamp"},

        {"KAITHPLST.THPSIZE",                             "Thread Pool Size"},
        {"KAITHPLST.THPSIZE.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.THPSIZE.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPMAXSZ",                             "Thread Pool Max Size"},
        {"KAITHPLST.TPMAXSZ.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPMAXSZ.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPACTTH",                             "Thread Pool Active Threads"},
        {"KAITHPLST.TPACTTH.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPACTTH.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPAVGAT",                             "Thread Pool Avg Active Threads"},
        {"KAITHPLST.TPAVGAT.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPAVGAT.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPMINAT",                             "Thread Pool Min Active Threads"},
        {"KAITHPLST.TPMINAT.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPMINAT.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPMAXAT",                             "Thread Pool Max Active Threads"},
        {"KAITHPLST.TPMAXAT.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPMAXAT.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPQLGTH",                             "Thread Pool Queue Length"},
        {"KAITHPLST.TPQLGTH.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPQLGTH.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPAVGQL",                             "Thread Pool Avg Queue Length"},
        {"KAITHPLST.TPAVGQL.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPAVGQL.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPMINQL",                             "Thread Pool Min Queue Length"},
        {"KAITHPLST.TPMINQL.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPMINQL.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPMAXQL",                             "Thread Pool Max Queue Length"},
        {"KAITHPLST.TPMAXQL.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPMAXQL.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPAVJBW",                             "Thread Pool Avg Job Wait"},
        {"KAITHPLST.TPAVJBW.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPAVJBW.ENUM.-100",                   "NO DATA"},

        {"KAITHPLST.TPTJOBS",                             "Thread Pool Total Jobs"},
        {"KAITHPLST.TPTJOBS.ENUM.-1",                     "NO DATA"},
        {"KAITHPLST.TPTJOBS.ENUM.-100",                   "NO DATA"},

};
return contents;
}

public Object[][] _oM6()
{
Object[][] contents = 
{
        {"TABLE.KAITACTST.OBJECT",                        "KAI TAKE ACTION STATUS"},
        {"KAITACTST.ORIGINNODE",                          "Node"},

        {"KAITACTST.TIMESTAMP",                           "Timestamp"},

        {"KAITACTST.TSKNAME",                             "Action Name"},

        {"KAITACTST.TSKSTAT",                             "Action Status"},
        {"KAITACTST.TSKSTAT.ENUM.0",                      "OK"},
        {"KAITACTST.TSKSTAT.ENUM.1",                      "NOT APPLICABLE"},
        {"KAITACTST.TSKSTAT.ENUM.10",                     "UNKNOWN"},
        {"KAITACTST.TSKSTAT.ENUM.11",                     "DEPENDENT STILL RUNNING"},
        {"KAITACTST.TSKSTAT.ENUM.12",                     "INSUFFICIENT USER AUTHORITY"},
        {"KAITACTST.TSKSTAT.ENUM.2",                      "GENERAL ERROR"},
        {"KAITACTST.TSKSTAT.ENUM.3",                      "WARNING"},
        {"KAITACTST.TSKSTAT.ENUM.4",                      "NOT RUNNING"},
        {"KAITACTST.TSKSTAT.ENUM.5",                      "DEPENDENT NOT RUNNING"},
        {"KAITACTST.TSKSTAT.ENUM.6",                      "ALREADY RUNNING"},
        {"KAITACTST.TSKSTAT.ENUM.7",                      "PREREQ NOT RUNNING"},
        {"KAITACTST.TSKSTAT.ENUM.8",                      "TIMED OUT"},
        {"KAITACTST.TSKSTAT.ENUM.9",                      "DOESNT EXIST"},

        {"KAITACTST.TSKAPRC",                             "Action App Return Code"},

        {"KAITACTST.TSKMSGE",                             "Action Message"},

        {"KAITACTST.TSKINST",                             "Action Instance"},

        {"KAITACTST.TSKOUTP",                             "Action Results"},

        {"KAITACTST.TSKCMND",                             "Action Command"},

        {"KAITACTST.TSKORGN",                             "Action Node"},

        {"KAITACTST.TSKSBND",                             "Action Subnode"},

        {"KAITACTST.TSKID",                               "Action ID"},

        {"KAITACTST.TSKTYPE",                             "Action Type"},
        {"KAITACTST.TSKTYPE.ENUM.0",                      "UNKNOWN"},
        {"KAITACTST.TSKTYPE.ENUM.1",                      "AUTOMATION"},

        {"KAITACTST.TSKOWNR",                             "Action Owner"},

};
return contents;
}

public Object[][] _oM7()
{
Object[][] contents = 
{
        {"TABLE.KAITCP.OBJECT",                           "KAI TCP"},
        {"KAITCP.ORIGINNODE",                             "Node"},

        {"KAITCP.TIMESTAMP",                              "Timestamp"},

        {"KAITCP.ACTIVEOPEN",                             "ActiveOpens"},
        {"KAITCP.ACTIVEOPEN.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.ACTIVEOPEN.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.PASSIVEOPE",                             "PassiveOpens"},
        {"KAITCP.PASSIVEOPE.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.PASSIVEOPE.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.ATTEMPTFAI",                             "AttemptFails"},
        {"KAITCP.ATTEMPTFAI.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.ATTEMPTFAI.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.ESTABRESET",                             "EstabResets"},
        {"KAITCP.ESTABRESET.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.ESTABRESET.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.CURRESTAB",                              "CurrEstab"},
        {"KAITCP.CURRESTAB.ENUM.-2147483648",             "Value Exceeds Minimum"},
        {"KAITCP.CURRESTAB.ENUM.2147483647",              "Value Exceeds Maximum"},

        {"KAITCP.RETRANSSEG",                             "RetransSegs"},
        {"KAITCP.RETRANSSEG.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.RETRANSSEG.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.INERRS",                                 "InErrs"},
        {"KAITCP.INERRS.ENUM.-2147483648",                "Value Exceeds Minimum"},
        {"KAITCP.INERRS.ENUM.2147483647",                 "Value Exceeds Maximum"},

        {"KAITCP.OUTRSTS",                                "OutRsts"},
        {"KAITCP.OUTRSTS.ENUM.-2147483648",               "Value Exceeds Minimum"},
        {"KAITCP.OUTRSTS.ENUM.2147483647",                "Value Exceeds Maximum"},

        {"KAITCP.SEGMENTSIN",                             "SegmentsIn"},
        {"KAITCP.SEGMENTSIN.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.SEGMENTSIN.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAITCP.SEGMENTSOU",                             "SegmentsOut"},
        {"KAITCP.SEGMENTSOU.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAITCP.SEGMENTSOU.ENUM.2147483647",             "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM8()
{
Object[][] contents = 
{
        {"TABLE.KAIMEMORY.OBJECT",                        "KAI MEMORY"},
        {"KAIMEMORY.ORIGINNODE",                          "Node"},

        {"KAIMEMORY.TIMESTAMP",                           "Timestamp"},

        {"KAIMEMORY.MEMTOTALSW",                          "memTotalSwap"},
        {"KAIMEMORY.MEMTOTALSW.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMTOTALSW.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMAVAILSW",                          "memAvailSwap"},
        {"KAIMEMORY.MEMAVAILSW.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMAVAILSW.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMTOTALRE",                          "memTotalReal"},
        {"KAIMEMORY.MEMTOTALRE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMTOTALRE.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMAVAILRE",                          "memAvailReal"},
        {"KAIMEMORY.MEMAVAILRE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMAVAILRE.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMTOTALFR",                          "memTotalFree"},
        {"KAIMEMORY.MEMTOTALFR.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMTOTALFR.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMSHARED",                           "memShared"},
        {"KAIMEMORY.MEMSHARED.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMSHARED.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMBUFFER",                           "memBuffer"},
        {"KAIMEMORY.MEMBUFFER.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMBUFFER.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAIMEMORY.MEMCACHED",                           "memCached"},
        {"KAIMEMORY.MEMCACHED.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAIMEMORY.MEMCACHED.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAIMEMORY.PHYSMEMUSE",                          "physMemUsedPercent"},
        {"KAIMEMORY.PHYSMEMUSE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.PHYSMEMUSE.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAIMEMORY.SWAPUSEDPE",                          "swapUsedPercent"},
        {"KAIMEMORY.SWAPUSEDPE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAIMEMORY.SWAPUSEDPE.ENUM.2147483647",          "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM9()
{
Object[][] contents = 
{
        {"TABLE.KAILOADAVE.OBJECT",                       "KAI LOADAVERAGES"},
        {"KAILOADAVE.ORIGINNODE",                         "Node"},

        {"KAILOADAVE.TIMESTAMP",                          "Timestamp"},

        {"KAILOADAVE.LOADAVERA1",                         "LoadAverageDuration"},

        {"KAILOADAVE.LOADAVG",                            "LoadAvg"},
        {"KAILOADAVE.LOADAVG.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAILOADAVE.LOADAVG.ENUM.2147483647",            "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM10()
{
Object[][] contents = 
{
        {"TABLE.KAISYSTEMS.OBJECT",                       "KAI SYSTEMSTATS"},
        {"KAISYSTEMS.ORIGINNODE",                         "Node"},

        {"KAISYSTEMS.TIMESTAMP",                          "Timestamp"},

        {"KAISYSTEMS.SWAPIN",                             "SwapIn"},
        {"KAISYSTEMS.SWAPIN.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAISYSTEMS.SWAPIN.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAISYSTEMS.SWAPOUT",                            "SwapOut"},
        {"KAISYSTEMS.SWAPOUT.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAISYSTEMS.SWAPOUT.ENUM.2147483647",            "Value Exceeds Maximum"},

        {"KAISYSTEMS.IOSENT",                             "IOSent"},
        {"KAISYSTEMS.IOSENT.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAISYSTEMS.IOSENT.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAISYSTEMS.IORECEIVE",                          "IOReceive"},
        {"KAISYSTEMS.IORECEIVE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAISYSTEMS.IORECEIVE.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAISYSTEMS.SYSINTERRU",                         "SysInterrupts"},
        {"KAISYSTEMS.SYSINTERRU.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAISYSTEMS.SYSINTERRU.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAISYSTEMS.SYSCONTEXT",                         "SysContext"},
        {"KAISYSTEMS.SYSCONTEXT.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAISYSTEMS.SYSCONTEXT.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAISYSTEMS.CPUUSER",                            "CpuUser"},
        {"KAISYSTEMS.CPUUSER.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAISYSTEMS.CPUUSER.ENUM.2147483647",            "Value Exceeds Maximum"},

        {"KAISYSTEMS.CPUSYSTEM",                          "CpuSystem"},
        {"KAISYSTEMS.CPUSYSTEM.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAISYSTEMS.CPUSYSTEM.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAISYSTEMS.CPUIDLE",                            "CpuIdle"},
        {"KAISYSTEMS.CPUIDLE.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAISYSTEMS.CPUIDLE.ENUM.2147483647",            "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM11()
{
Object[][] contents = 
{
        {"TABLE.KAISYSTEM.OBJECT",                        "KAI SYSTEM"},
        {"KAISYSTEM.ORIGINNODE",                          "Node"},

        {"KAISYSTEM.TIMESTAMP",                           "Timestamp"},

        {"KAISYSTEM.SYSUPTIME",                           "sysUpTime"},

        {"KAISYSTEM.SYSNAME",                             "sysName"},

        {"KAISYSTEM.IPADDRESS",                           "IPAddress"},

};
return contents;
}

public Object[][] _oM12()
{
Object[][] contents = 
{
        {"TABLE.KAIINTERFA.OBJECT",                       "KAI INTERFACES"},
        {"KAIINTERFA.ORIGINNODE",                         "Node"},

        {"KAIINTERFA.TIMESTAMP",                          "Timestamp"},

        {"KAIINTERFA.INTERFACEN",                         "InterfaceName"},

        {"KAIINTERFA.INTERFACET",                         "InterfaceType"},
        {"KAIINTERFA.INTERFACET.ENUM.1",                  "other"},
        {"KAIINTERFA.INTERFACET.ENUM.10",                 "iso88026Man"},
        {"KAIINTERFA.INTERFACET.ENUM.100",                "voiceEM"},
        {"KAIINTERFA.INTERFACET.ENUM.101",                "voiceFXO"},
        {"KAIINTERFA.INTERFACET.ENUM.102",                "voiceFXS"},
        {"KAIINTERFA.INTERFACET.ENUM.103",                "voiceEncap"},
        {"KAIINTERFA.INTERFACET.ENUM.104",                "voiceOverIp"},
        {"KAIINTERFA.INTERFACET.ENUM.105",                "atmDxi"},
        {"KAIINTERFA.INTERFACET.ENUM.106",                "atmFuni"},
        {"KAIINTERFA.INTERFACET.ENUM.107",                "atmIma"},
        {"KAIINTERFA.INTERFACET.ENUM.108",                "pppMultilinkBundle"},
        {"KAIINTERFA.INTERFACET.ENUM.109",                "ipOverCdlc"},
        {"KAIINTERFA.INTERFACET.ENUM.11",                 "starLan"},
        {"KAIINTERFA.INTERFACET.ENUM.110",                "ipOverClaw"},
        {"KAIINTERFA.INTERFACET.ENUM.111",                "stackToStack"},
        {"KAIINTERFA.INTERFACET.ENUM.112",                "virtualIpAddress"},
        {"KAIINTERFA.INTERFACET.ENUM.113",                "mpc"},
        {"KAIINTERFA.INTERFACET.ENUM.114",                "ipOverAtm"},
        {"KAIINTERFA.INTERFACET.ENUM.115",                "iso88025Fiber"},
        {"KAIINTERFA.INTERFACET.ENUM.116",                "tdlc"},
        {"KAIINTERFA.INTERFACET.ENUM.117",                "gigabitEthernet"},
        {"KAIINTERFA.INTERFACET.ENUM.118",                "hdlc"},
        {"KAIINTERFA.INTERFACET.ENUM.119",                "lapf"},
        {"KAIINTERFA.INTERFACET.ENUM.12",                 "proteon10Mbit"},
        {"KAIINTERFA.INTERFACET.ENUM.120",                "v37"},
        {"KAIINTERFA.INTERFACET.ENUM.121",                "x25mlp"},
        {"KAIINTERFA.INTERFACET.ENUM.122",                "x25huntGroup"},
        {"KAIINTERFA.INTERFACET.ENUM.123",                "transpHdlc"},
        {"KAIINTERFA.INTERFACET.ENUM.124",                "interleave"},
        {"KAIINTERFA.INTERFACET.ENUM.125",                "fast"},
        {"KAIINTERFA.INTERFACET.ENUM.126",                "ip"},
        {"KAIINTERFA.INTERFACET.ENUM.127",                "docsCableMaclayer"},
        {"KAIINTERFA.INTERFACET.ENUM.128",                "docsCableDownstream"},
        {"KAIINTERFA.INTERFACET.ENUM.129",                "docsCableUpstream"},
        {"KAIINTERFA.INTERFACET.ENUM.13",                 "proteon80Mbit"},
        {"KAIINTERFA.INTERFACET.ENUM.130",                "a12MppSwitch"},
        {"KAIINTERFA.INTERFACET.ENUM.131",                "tunnel"},
        {"KAIINTERFA.INTERFACET.ENUM.132",                "coffee"},
        {"KAIINTERFA.INTERFACET.ENUM.133",                "ces"},
        {"KAIINTERFA.INTERFACET.ENUM.134",                "atmSubInterface"},
        {"KAIINTERFA.INTERFACET.ENUM.135",                "l2vlan"},
        {"KAIINTERFA.INTERFACET.ENUM.136",                "l3ipvlan"},
        {"KAIINTERFA.INTERFACET.ENUM.137",                "l3ipxvlan"},
        {"KAIINTERFA.INTERFACET.ENUM.138",                "digitalPowerLine"},
        {"KAIINTERFA.INTERFACET.ENUM.139",                "mediaMailOverIP"},
        {"KAIINTERFA.INTERFACET.ENUM.14",                 "hyperchannel"},
        {"KAIINTERFA.INTERFACET.ENUM.140",                "dtm"},
        {"KAIINTERFA.INTERFACET.ENUM.141",                "dcm"},
        {"KAIINTERFA.INTERFACET.ENUM.142",                "ipForward"},
        {"KAIINTERFA.INTERFACET.ENUM.143",                "msdsl"},
        {"KAIINTERFA.INTERFACET.ENUM.144",                "ieee1394"},
        {"KAIINTERFA.INTERFACET.ENUM.15",                 "fddi"},
        {"KAIINTERFA.INTERFACET.ENUM.16",                 "lapb"},
        {"KAIINTERFA.INTERFACET.ENUM.17",                 "sdlc"},
        {"KAIINTERFA.INTERFACET.ENUM.18",                 "ds1"},
        {"KAIINTERFA.INTERFACET.ENUM.19",                 "e1"},
        {"KAIINTERFA.INTERFACET.ENUM.2",                  "regular1822"},
        {"KAIINTERFA.INTERFACET.ENUM.20",                 "basicISDN"},
        {"KAIINTERFA.INTERFACET.ENUM.21",                 "primaryISDN"},
        {"KAIINTERFA.INTERFACET.ENUM.22",                 "propPointToPointSerial"},
        {"KAIINTERFA.INTERFACET.ENUM.23",                 "ppp"},
        {"KAIINTERFA.INTERFACET.ENUM.24",                 "softwareLoopback"},
        {"KAIINTERFA.INTERFACET.ENUM.25",                 "eon"},
        {"KAIINTERFA.INTERFACET.ENUM.26",                 "ethernet3Mbit"},
        {"KAIINTERFA.INTERFACET.ENUM.27",                 "nsip"},
        {"KAIINTERFA.INTERFACET.ENUM.28",                 "slip"},
        {"KAIINTERFA.INTERFACET.ENUM.29",                 "ultra"},
        {"KAIINTERFA.INTERFACET.ENUM.3",                  "hdh1822"},
        {"KAIINTERFA.INTERFACET.ENUM.30",                 "ds3"},
        {"KAIINTERFA.INTERFACET.ENUM.31",                 "sip"},
        {"KAIINTERFA.INTERFACET.ENUM.32",                 "frameRelay"},
        {"KAIINTERFA.INTERFACET.ENUM.33",                 "rs232"},
        {"KAIINTERFA.INTERFACET.ENUM.34",                 "para"},
        {"KAIINTERFA.INTERFACET.ENUM.35",                 "arcnet"},
        {"KAIINTERFA.INTERFACET.ENUM.36",                 "arcnetPlus"},
        {"KAIINTERFA.INTERFACET.ENUM.37",                 "atm"},
        {"KAIINTERFA.INTERFACET.ENUM.38",                 "miox25"},
        {"KAIINTERFA.INTERFACET.ENUM.39",                 "sonet"},
        {"KAIINTERFA.INTERFACET.ENUM.4",                  "ddnX25"},
        {"KAIINTERFA.INTERFACET.ENUM.40",                 "x25ple"},
        {"KAIINTERFA.INTERFACET.ENUM.41",                 "iso88022llc"},
        {"KAIINTERFA.INTERFACET.ENUM.42",                 "localTalk"},
        {"KAIINTERFA.INTERFACET.ENUM.43",                 "smdsDxi"},
        {"KAIINTERFA.INTERFACET.ENUM.44",                 "frameRelayService"},
        {"KAIINTERFA.INTERFACET.ENUM.45",                 "v35"},
        {"KAIINTERFA.INTERFACET.ENUM.46",                 "hssi"},
        {"KAIINTERFA.INTERFACET.ENUM.47",                 "hippi"},
        {"KAIINTERFA.INTERFACET.ENUM.48",                 "modem"},
        {"KAIINTERFA.INTERFACET.ENUM.49",                 "aal5"},
        {"KAIINTERFA.INTERFACET.ENUM.5",                  "rfc877x25"},
        {"KAIINTERFA.INTERFACET.ENUM.50",                 "sonetPath"},
        {"KAIINTERFA.INTERFACET.ENUM.51",                 "sonetVT"},
        {"KAIINTERFA.INTERFACET.ENUM.52",                 "smdsIcip"},
        {"KAIINTERFA.INTERFACET.ENUM.53",                 "propVirtual"},
        {"KAIINTERFA.INTERFACET.ENUM.54",                 "propMultiplexor"},
        {"KAIINTERFA.INTERFACET.ENUM.55",                 "ieee80212"},
        {"KAIINTERFA.INTERFACET.ENUM.56",                 "fibre-channel"},
        {"KAIINTERFA.INTERFACET.ENUM.57",                 "hippiInterfaces"},
        {"KAIINTERFA.INTERFACET.ENUM.58",                 "frameRelayInterconnect"},
        {"KAIINTERFA.INTERFACET.ENUM.59",                 "aflane8023"},
        {"KAIINTERFA.INTERFACET.ENUM.6",                  "ethernetCsmacd"},
        {"KAIINTERFA.INTERFACET.ENUM.60",                 "aflane8025"},
        {"KAIINTERFA.INTERFACET.ENUM.61",                 "cctEmul"},
        {"KAIINTERFA.INTERFACET.ENUM.62",                 "fastEther"},
        {"KAIINTERFA.INTERFACET.ENUM.63",                 "isdn"},
        {"KAIINTERFA.INTERFACET.ENUM.64",                 "v11"},
        {"KAIINTERFA.INTERFACET.ENUM.65",                 "v36"},
        {"KAIINTERFA.INTERFACET.ENUM.66",                 "g703-64k"},
        {"KAIINTERFA.INTERFACET.ENUM.67",                 "g703-2mb"},
        {"KAIINTERFA.INTERFACET.ENUM.68",                 "qllc"},
        {"KAIINTERFA.INTERFACET.ENUM.69",                 "fastEtherFX"},
        {"KAIINTERFA.INTERFACET.ENUM.7",                  "iso88023Csmacd"},
        {"KAIINTERFA.INTERFACET.ENUM.70",                 "channel"},
        {"KAIINTERFA.INTERFACET.ENUM.71",                 "iEEE80211"},
        {"KAIINTERFA.INTERFACET.ENUM.72",                 "ibm370parChan"},
        {"KAIINTERFA.INTERFACET.ENUM.73",                 "eSCON"},
        {"KAIINTERFA.INTERFACET.ENUM.74",                 "dLSw"},
        {"KAIINTERFA.INTERFACET.ENUM.75",                 "iSDNs"},
        {"KAIINTERFA.INTERFACET.ENUM.76",                 "iSDNu"},
        {"KAIINTERFA.INTERFACET.ENUM.77",                 "lapd"},
        {"KAIINTERFA.INTERFACET.ENUM.78",                 "ip-switch"},
        {"KAIINTERFA.INTERFACET.ENUM.79",                 "rsrb"},
        {"KAIINTERFA.INTERFACET.ENUM.8",                  "iso88024TokenBus"},
        {"KAIINTERFA.INTERFACET.ENUM.80",                 "atm-logical"},
        {"KAIINTERFA.INTERFACET.ENUM.81",                 "ds0"},
        {"KAIINTERFA.INTERFACET.ENUM.82",                 "ds0Bundle"},
        {"KAIINTERFA.INTERFACET.ENUM.83",                 "bsc"},
        {"KAIINTERFA.INTERFACET.ENUM.84",                 "async"},
        {"KAIINTERFA.INTERFACET.ENUM.85",                 "cnr"},
        {"KAIINTERFA.INTERFACET.ENUM.86",                 "iso88025Dtr"},
        {"KAIINTERFA.INTERFACET.ENUM.87",                 "eplrs"},
        {"KAIINTERFA.INTERFACET.ENUM.88",                 "arap"},
        {"KAIINTERFA.INTERFACET.ENUM.89",                 "propCnls"},
        {"KAIINTERFA.INTERFACET.ENUM.9",                  "iso88025TokenRing"},
        {"KAIINTERFA.INTERFACET.ENUM.90",                 "hostPad"},
        {"KAIINTERFA.INTERFACET.ENUM.91",                 "termPad"},
        {"KAIINTERFA.INTERFACET.ENUM.92",                 "frameRelayMPI"},
        {"KAIINTERFA.INTERFACET.ENUM.93",                 "x213"},
        {"KAIINTERFA.INTERFACET.ENUM.94",                 "adsl"},
        {"KAIINTERFA.INTERFACET.ENUM.95",                 "radsl"},
        {"KAIINTERFA.INTERFACET.ENUM.96",                 "sdsl"},
        {"KAIINTERFA.INTERFACET.ENUM.97",                 "vdsl"},
        {"KAIINTERFA.INTERFACET.ENUM.98",                 "iso88025CRFPInt"},
        {"KAIINTERFA.INTERFACET.ENUM.99",                 "myrinet"},

        {"KAIINTERFA.SPEED",                              "Speed"},
        {"KAIINTERFA.SPEED.ENUM.-2147483648",             "Value Exceeds Minimum"},
        {"KAIINTERFA.SPEED.ENUM.2147483647",              "Value Exceeds Maximum"},

        {"KAIINTERFA.PHYSADDRES",                         "PhysAddress"},

        {"KAIINTERFA.ADMINSTATU",                         "AdminStatus"},
        {"KAIINTERFA.ADMINSTATU.ENUM.1",                  "up"},
        {"KAIINTERFA.ADMINSTATU.ENUM.2",                  "down"},
        {"KAIINTERFA.ADMINSTATU.ENUM.3",                  "testing"},

        {"KAIINTERFA.OPERSTATUS",                         "OperStatus"},
        {"KAIINTERFA.OPERSTATUS.ENUM.1",                  "up"},
        {"KAIINTERFA.OPERSTATUS.ENUM.2",                  "down"},
        {"KAIINTERFA.OPERSTATUS.ENUM.3",                  "testing"},
        {"KAIINTERFA.OPERSTATUS.ENUM.4",                  "unknown"},
        {"KAIINTERFA.OPERSTATUS.ENUM.5",                  "dormant"},
        {"KAIINTERFA.OPERSTATUS.ENUM.6",                  "notPresent"},
        {"KAIINTERFA.OPERSTATUS.ENUM.7",                  "lowerLayerDown"},

        {"KAIINTERFA.PKTSIN",                             "PktsIn"},
        {"KAIINTERFA.PKTSIN.ENUM.-2147483648",            "Value Exceeds Minimum"},
        {"KAIINTERFA.PKTSIN.ENUM.2147483647",             "Value Exceeds Maximum"},

        {"KAIINTERFA.PKTSOUT",                            "PktsOut"},
        {"KAIINTERFA.PKTSOUT.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAIINTERFA.PKTSOUT.ENUM.2147483647",            "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM13()
{
Object[][] contents = 
{
        {"TABLE.KAIHRSTORA.OBJECT",                       "KAI HRSTORAGETABLE"},
        {"KAIHRSTORA.ORIGINNODE",                         "Node"},

        {"KAIHRSTORA.TIMESTAMP",                          "Timestamp"},

        {"KAIHRSTORA.INDEX",                              "Index"},
        {"KAIHRSTORA.INDEX.ENUM.-2147483648",             "Value Exceeds Minimum"},
        {"KAIHRSTORA.INDEX.ENUM.2147483647",              "Value Exceeds Maximum"},

        {"KAIHRSTORA.TYPE",                               "Type"},

        {"KAIHRSTORA.DESCR",                              "Descr"},

        {"KAIHRSTORA.BLOCKSZ",                            "BlockSz"},
        {"KAIHRSTORA.BLOCKSZ.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAIHRSTORA.BLOCKSZ.ENUM.2147483647",            "Value Exceeds Maximum"},

        {"KAIHRSTORA.SIZE",                               "Size"},
        {"KAIHRSTORA.SIZE.ENUM.-2147483648",              "Value Exceeds Minimum"},
        {"KAIHRSTORA.SIZE.ENUM.2147483647",               "Value Exceeds Maximum"},

        {"KAIHRSTORA.USED",                               "Used"},
        {"KAIHRSTORA.USED.ENUM.-2147483648",              "Value Exceeds Minimum"},
        {"KAIHRSTORA.USED.ENUM.2147483647",               "Value Exceeds Maximum"},

        {"KAIHRSTORA.ALLOCFAILU",                         "AllocFailures"},
        {"KAIHRSTORA.ALLOCFAILU.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAIHRSTORA.ALLOCFAILU.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAIHRSTORA.PCTUSED",                            "PctUsed"},
        {"KAIHRSTORA.PCTUSED.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAIHRSTORA.PCTUSED.ENUM.2147483647",            "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM14()
{
Object[][] contents = 
{
        {"TABLE.KAIMGTPOS.OBJECT",                        "KAI MGT PERFORMANCE OBJECT STATUS"},
        {"KAIMGTPOS.ORIGINNODE",                          "Node"},

        {"KAIMGTPOS.TIMESTAMP",                           "Timestamp"},

        {"KAIMGTPOS.ATTRGRP",                             "Query Name"},

        {"KAIMGTPOS.OBJNAME",                             "Object Name"},

        {"KAIMGTPOS.OBJTYPE",                             "Object Type"},
        {"KAIMGTPOS.OBJTYPE.ENUM.0",                      "WMI"},
        {"KAIMGTPOS.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"KAIMGTPOS.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"KAIMGTPOS.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"KAIMGTPOS.OBJTYPE.ENUM.12",                     "JDBC"},
        {"KAIMGTPOS.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"KAIMGTPOS.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"KAIMGTPOS.OBJTYPE.ENUM.15",                     "FILTER"},
        {"KAIMGTPOS.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"KAIMGTPOS.OBJTYPE.ENUM.17",                     "PING"},
        {"KAIMGTPOS.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"KAIMGTPOS.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"KAIMGTPOS.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"KAIMGTPOS.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"KAIMGTPOS.OBJTYPE.ENUM.3",                      "JMX"},
        {"KAIMGTPOS.OBJTYPE.ENUM.4",                      "SNMP"},
        {"KAIMGTPOS.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"KAIMGTPOS.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"KAIMGTPOS.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"KAIMGTPOS.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"KAIMGTPOS.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"KAIMGTPOS.OBJSTTS",                             "Object Status"},
        {"KAIMGTPOS.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"KAIMGTPOS.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"KAIMGTPOS.ERRCODE",                             "Error Code"},
        {"KAIMGTPOS.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"KAIMGTPOS.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"KAIMGTPOS.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"KAIMGTPOS.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"KAIMGTPOS.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"KAIMGTPOS.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"KAIMGTPOS.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"KAIMGTPOS.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"KAIMGTPOS.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"KAIMGTPOS.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"KAIMGTPOS.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"KAIMGTPOS.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"KAIMGTPOS.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"KAIMGTPOS.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"KAIMGTPOS.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"KAIMGTPOS.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"KAIMGTPOS.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"KAIMGTPOS.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"KAIMGTPOS.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"KAIMGTPOS.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"KAIMGTPOS.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"KAIMGTPOS.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"KAIMGTPOS.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"KAIMGTPOS.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"KAIMGTPOS.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"KAIMGTPOS.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"KAIMGTPOS.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"KAIMGTPOS.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"KAIMGTPOS.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"KAIMGTPOS.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"KAIMGTPOS.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"KAIMGTPOS.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"KAIMGTPOS.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"KAIMGTPOS.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"KAIMGTPOS.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"KAIMGTPOS.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"KAIMGTPOS.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"KAIMGTPOS.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"KAIMGTPOS.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"KAIMGTPOS.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"KAIMGTPOS.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"KAIMGTPOS.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"KAIMGTPOS.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"KAIMGTPOS.ERRCODE.ENUM.66",                     "DISABLED"},
        {"KAIMGTPOS.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"KAIMGTPOS.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"KAIMGTPOS.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"KAIMGTPOS.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"KAIMGTPOS.ERRCODE.ENUM.70",                     "ICMP SOCKETS FAILED"},
        {"KAIMGTPOS.ERRCODE.ENUM.71",                     "DUPLICATE CONF FILE"},
        {"KAIMGTPOS.ERRCODE.ENUM.72",                     "DELETED CONFIGURATION"},
        {"KAIMGTPOS.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"KAIMGTPOS.COLSTRT",                             "Last Collection Start"},
        {"KAIMGTPOS.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAIMGTPOS.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAIMGTPOS.COLFINI",                             "Last Collection Finished"},
        {"KAIMGTPOS.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAIMGTPOS.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAIMGTPOS.COLDURA",                             "Last Collection Duration"},

        {"KAIMGTPOS.COLAVGD",                             "Average Collection Duration"},
        {"KAIMGTPOS.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"KAIMGTPOS.REFRINT",                             "Refresh Interval"},

        {"KAIMGTPOS.NUMCOLL",                             "Number of Collections"},

        {"KAIMGTPOS.CACHEHT",                             "Cache Hits"},

        {"KAIMGTPOS.CACHEMS",                             "Cache Misses"},

        {"KAIMGTPOS.CACHPCT",                             "Cache Hit Percent"},

        {"KAIMGTPOS.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

 
  /**
   * Provide access to singleton Bundle wrapper for this resource bundle.
   *
   * @return reference to Bundle wrapper for this resource bundle
   */
//  Begin do not translate block
  public static final Bundle getBundle()
  {
    // if singleton bundle not yet created ...
    if (bundle == null)
    {
      // ... create it now
      bundle = new Bundle(BUNDLE_ID, BUNDLE_NAME, BundleManager.getCurrentLocale());
      BundleManager.addBundle(bundle);

      // make long-lived reference to singleton instance
      SingletonManager.add(bundle);
    }

    // return result
    return bundle;
  }

  /**
   * Implements Versioned interface
   */
  public Object getVersion()
  {
    return version.getVersion();
  }

  /**
   * Implements Versioned interface
   */
  public int compareVersion(Object targetVersion)
  {
    return version.compareVersion(targetVersion);
  }

  /**
   * Implementation of ResourceBundle.getKeys.
   */
  public Enumeration getKeys()
  {
    if (map.isEmpty())
      loadMap();

    return new Enumeration()
    {
      private Iterator mi = map.keySet().iterator();

      public boolean hasMoreElements()
      {
        return mi.hasNext();
      }

      public Object nextElement()
      {
        return mi.next();
      }
    };
  }

  /**
   * Gets an object for the given key from this resource bundle.
   * Returns null if this resource bundle does not contain an
   * object for the given key.
   *
   * @param key the key for the desired object
   * @exception NullPointerException if <code>key</code> is <code>null</code>
   * @return the object for the given key, or null
   */
  public Object handleGetObject(String key)
  {
    if (key == null)
      throw new NullPointerException();

    if (map.isEmpty())
      loadMap();

    return map.get(key); 
  }

  // load the resource map
  private void loadMap() 
  {
    Method[] methods = getClass().getDeclaredMethods();

    try
    {
      for (int i=0; i < methods.length; i++)
      {
        Method method = methods[i];

        if (method.getName().startsWith("_oM")) // one of the resource methods
        {
          Object[][] contents = (Object[][])method.invoke(this, (Object[]) null);

          for (int j = 0; j < contents.length; ++j)
          {
            map.put((String)contents[j][0], contents[j][1]);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  private static Bundle bundle;
  private static HashMap map = new HashMap(43);
//End do not translate block
}
