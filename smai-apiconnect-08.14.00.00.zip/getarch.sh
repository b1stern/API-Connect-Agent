#!/bin/sh

CANDLEHOME=$1

archTbl="$CANDLEHOME/registry/archdsc.tbl"
. "${CANDLEHOME}/bin/dynarch.shl"
if [ -n "$2" ]; then
	cd "$2"
fi
cd ira/agent
SUPPORTED=*

for ARCH in $SUPPORTED
do
	if [ "$ARCH" = "$CANDLEARCH" ]; then
		echo $ARCH
		exit 0
	fi
done

ARCHTYPE=`echo $CANDLEARCH | sed 's/^\([a-z]*\)[0-9]*/\1/'`
BITS=`echo $CANDLEARCH | sed 's/^.*\([0-9]\)$/\1/'`

case "$ARCHTYPE" in
	"aix")  if [ "$BITS" = "3" ]; then
				echo aix523
			elif [ "$BITS" = "6" ]; then
				echo aix526
			else
				echo UNSUPPORTED
			fi
			;;
	"sol")  SUBTYPE=`echo $CANDLEARCH | sed 's/^[a-z]*\([0-9]\)[0-9]*$/\1/'`
			if [ "$SUBTYPE" = "2" -o "$SUBTYPE" = "5" ]; then
				if [ "$BITS" = "3" ]; then
					echo sol283
				elif [ "$BITS" = "6" ]; then
					echo sol286
				else
					echo UNSUPPORTED
				fi
			elif [ "$SUBTYPE" = "6" ]; then
				if [ "$BITS" = "6" ]; then
					echo sol606
				else
					echo UNSUPPORTED
				fi
			else
				echo UNSUPPORTED
			fi
			;;
	"hp")   if [ "$BITS" = "1" -o "$BITS" = "3" ]; then
				echo hp11
			elif [ "$BITS" = "6" ]; then
				echo hp116
			else
				echo UNSUPPORTED
			fi
			;;
	"hpi")  if [ "$BITS" = "6" ]; then
				echo hpi116
			else
				echo UNSUPPORTED
			fi
			;;
	"li")   if [ "$BITS" = "2" ]; then
				echo li6242
			elif [ "$BITS" = "3" ]; then
				echo li6243
			else
				echo UNSUPPORTED
			fi
			;;
	"lia")  if [ "$BITS" = "6" ]; then
				echo lia266
			else
				echo UNSUPPORTED
			fi
			;;
	"lpp")  if [ "$BITS" = "6" ]; then
				echo lpp266
			else
				echo UNSUPPORTED
			fi
			;;
	"lpl")  if [ "$BITS" = "6" ]; then
				echo lpl266
			else
				echo UNSUPPORTED
			fi
			;;
	"ls")   if [ "$BITS" = "3" ]; then
				echo ls3243
			elif [ "$BITS" = "6" ]; then
				echo ls3246
			else
				echo UNSUPPORTED
			fi
			;;
	"lx")   if [ "$BITS" = "6" ]; then
				echo lx8266
			else
				echo UNSUPPORTED
			fi
			;;
esac
exit 0
