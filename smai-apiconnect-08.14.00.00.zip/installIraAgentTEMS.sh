#!/bin/sh
# ----------------------------------------------------------------
# Monitoring Agent for APIConnect
# Version 814
# Unix TEMS Installation Script
#
# Licensed Materials - Property of IBM
# Copyright IBM Corp. , 2017. All Rights Reserved
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
# This file was created by IBM Agent Builder
# Version 6.3.4
#	Agent Builder Common.v6.3.4 201703151048
#	IBM Tivoli Monitoring Agent Generator.v6.3.4 201703151048
#	IBM Agent Builder UI.v6.3.4 201703151048
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.4 201703151048
#	Agent Builder CIM Data Provider.v6.3.4 201703151048
#	Agent Builder Custom Data Provider.v6.3.4 201703151048
#	Agent Builder HTTP Data Provider.v6.3.4 201703151048
#	Agent Builder ICMP Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.4 201703151048
#	Agent Builder Log Data Provider.v6.3.4 201703151048
#	Agent Builder SNMP Data Provider.v6.3.4 201703151048
#	Agent Builder WMI Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.4 201703151048
#	Agent Builder Dashboard Support.v6.3.4 201703151048
#	IBM Tivoli Monitoring Remote Deploy.v6.3.4 201703151048
#	IBM Tivoli Omnibus.v6.3.4 201703151048
# ----------------------------------------------------------------
fail()
{
    echo "Installation failed.  Please see the log in ${CANDLE_HOME}/logs/k${PRODUCT_LOWER}_TEMSInstall.log"
    exit 1
}

makedir()
{
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
    fi
}
usage()
{
    echo "usage InstallIraAgentTEMS.sh <ITM home> [[-h <HUB TEMS hostname>] -u <HUB TEMS username> [-p <HUB TEMS password>]]"
    echo "If HUB TEMS and Username are provided but password is not, you will be prompted for the password"
    exit 1
}
addInstallDateToVerFile()
{
    VERARCH=`uname -a | grep "SunOS"`
    if [ $? -eq 0 ]; then
        epochTime=`nawk 'BEGIN{print srand()}'`
    else
        epochTime=`date +%s`
    fi
    echo "installDate = root|${epochTime}000|" >> $1
}

set +x
CANDLE_HOME=$1
export CANDLE_HOME
unset NO_RESTART_TEMS
unset HUB_TEMS_HOST
unset HUB_TEMS_USER
unset HUB_TEMS_PASS
while [ -n "$1" ]
do
    shift
    case "$1" in
        "-n") NO_RESTART_TEMS=1
        ;;
        "-h") HUB_TEMS_HOST="$2"
        ;;
        "-u") HUB_TEMS_USER="$2"
        ;;
        "-p") HUB_TEMS_PASS="$2"
        ;;
    esac
done
PRODUCT_CODE=ai
PRODUCT_LOWER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:upper:]' '[:lower:]')`
PRODUCT_UPPER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:lower:]' '[:upper:]')`
if [ -z "$CANDLE_HOME"  ]; then
    usage
fi
if [ -n "$HUB_TEMS_HOST"  ]; then
    if [ -z "$HUB_TEMS_USER" ]; then
        usage
    fi
fi
if [ -n "$HUB_TEMS_USER"  ]; then
    if [ -z "$HUB_TEMS_HOST" ]; then
        HUB_TEMS_HOST=localhost
    fi
fi
$CANDLE_HOME/bin/cinfo -p ms > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo The ITM installation directory passed in does not contain a
    echo Tivoli Enterprise Monitoring Server installation.
    exit 1
fi
if [ ! -d "${CANDLE_HOME}/logs" ]; then
    mkdir -p "${CANDLE_HOME}/logs"
fi
exec 2> "${CANDLE_HOME}/logs/k${PRODUCT_LOWER}_TEMSInstall.log"
set -x

THIS_HOST=`hostname | cut -f1 -d.`
TEMSARCH=`$CANDLE_HOME/bin/cinfo -p ms | grep '(ms)' | awk -F: '{print $1}' | tr -d " "`
if [ -f "${CANDLE_HOME}/registry/ms${TEMSARCH}.ver" ]; then
    MSVER="${CANDLE_HOME}/registry/ms${TEMSARCH}.ver"
else
    MSVER=`ls -1 "${CANDLE_HOME}"/registry/ms*.ver | head -1`
fi
if [ -z "${MSVER}" ]; then
    echo No MS version file found, can not install.
    exit 1
fi
MSVRMF=`egrep "^VRMF[ ]*=" "${MSVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${MSVRMF}" -lt "06210000" ]; then
    echo This agent requires ITM version 06210000 \(6.2.1\) or higher to work correctly.
    echo The ITM installation in "${CANDLE_HOME}" is version ${MSVRMF},
    echo thus the agent can not install.
    exit 1
fi

TEMSNAMES=`/bin/ls -1 $CANDLE_HOME/config | egrep "_ms_.*.config$" | sed 's/.*_ms_\(.*\).config/\1/'`
for TN in $TEMSNAMES
do
    if [ -d ${CANDLE_HOME}/tables/${TN} ]; then
        TEMSNAME=$TN
        break
    fi
done
if [ -z "$TEMSNAME" ]; then
    TEMSNAME=$THIS_HOST
fi
TEMSVRMF=`egrep "^VRMF[ ]*=" ${CANDLE_HOME}/registry/ms${TEMSARCH}.ver | awk -F= '{print $2}' | sed 's/ //g'`
if [ "$TEMSVRMF" -lt "06200100" -a -n "${HUB_TEMS_HOST}" ]; then
    echo Providing login information to load TEMS without restarting is not supported until
    echo ITM 6.2FP1.
    fail
fi

if [ "$TEMSVRMF" -ge 06200100 -a -n "$HUB_TEMS_HOST" ]; then
    # If we were not given a password, leave it off and let tacmd login prompt for it.
    if [ -z "${HUB_TEMS_PASS}" ]; then
        ${CANDLE_HOME}/bin/tacmd login -s ${HUB_TEMS_HOST} -u ${HUB_TEMS_USER}
    else
        set +x
        echo ${CANDLE_HOME}/bin/tacmd login -s ${HUB_TEMS_HOST} -u ${HUB_TEMS_USER} -p "********" >&2 
        ${CANDLE_HOME}/bin/tacmd login -s ${HUB_TEMS_HOST} -u ${HUB_TEMS_USER} -p "${HUB_TEMS_PASS}" 
    fi
    if [ "$?" -ne "0" ]; then
        set -x
        echo Login to HUB TEMS ${HUB_TEMS_HOST} failed.
        exit 10
    fi
    set -x
fi

# If there's already an entry for this PC, comment it out if it's wrong
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    # There's already an entry for this product code-- 
    # If it differs from ours, comment it out and add our new one
    awk -F\| '{if ($1 == "ai" && $2 != "Monitoring Agent for APIConnect") 
                { printf("#%s\n",$0) }
               else
                { print $0} }' "$CANDLE_HOME/registry/proddsc.tbl" > "$CANDLE_HOME/registry/proddsc.tbl.$$" || fail
    mv -f "$CANDLE_HOME/registry/proddsc.tbl.$$" "$CANDLE_HOME/registry/proddsc.tbl" || fail
fi
# We may have commented some out, but one might have been right, so only add if we need to
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    cat ./ira/agent/common/proddsc.tbl >> $CANDLE_HOME/registry/proddsc.tbl  || fail
fi
KSM_TEMP_DIR=/tmp/k${PRODUCT_LOWER}.$$
makedir ${KSM_TEMP_DIR}/TEMS/SQLLIB || fail
makedir ${KSM_TEMP_DIR}/TEMS/RKDSCATL || fail
makedir ${KSM_TEMP_DIR}/TEMS/ATTRLIB || fail
cp ./ira/agent/common/*k${PRODUCT_LOWER}.sql ${KSM_TEMP_DIR}/TEMS/SQLLIB/k${PRODUCT_LOWER}.sql || fail
cp ./ira/agent/common/*k${PRODUCT_LOWER}_del.sql ${KSM_TEMP_DIR}/TEMS/SQLLIB/k${PRODUCT_LOWER}_del.sql || fail
cp ./ira/agent/common/*k${PRODUCT_LOWER}_upg.sql ${KSM_TEMP_DIR}/TEMS/SQLLIB/k${PRODUCT_LOWER}_upg.sql || fail
cp ./ira/agent/common/k${PRODUCT_LOWER}.cat ${KSM_TEMP_DIR}/TEMS/RKDSCATL/k$PRODUCT_LOWER.cat || fail
cp ./ira/agent/common/k${PRODUCT_LOWER}.atr ${KSM_TEMP_DIR}/TEMS/ATTRLIB/k$PRODUCT_LOWER.atr || fail
OSTYPE=`uname`
case $OSTYPE in
    "AIX") LIBPATH_VAR=LIBPATH
    ;;
    "HP-UX") LIBPATH_VAR=SHLIB_PATH
    ;;
    "SunOS"|"Linux") LIBPATH_VAR=LD_LIBRARY_PATH
    ;;
esac

TEMS_LIBPATH=`egrep "^${LIBPATH_VAR}=" ${CANDLE_HOME}/config/${THIS_HOST}_ms_${TEMSNAME}.config | sed "s/'//g"`
TEMS_PATH=`egrep "^PATH=" ${CANDLE_HOME}/config/${THIS_HOST}_ms_${TEMSNAME}.config | sed "s/'//g"`
eval $TEMS_LIBPATH
eval $TEMS_PATH
export $LIBPATH_VAR PATH
TEMS_IS_RUNNING=`${CANDLE_HOME}/bin/cinfo -r | egrep "^${THIS_HOST}" | awk '{print $2}' |
while read RUNNING_PROD
do
    if [ "$RUNNING_PROD" = "ms" ]; then
        echo 1
    fi
done`
SAVDIR=`pwd`
if [ -z "$TEMS_IS_RUNNING" ]; then
    cd /
    $CANDLE_HOME/bin/CandleServer start $TEMSNAME || fail
    cd $SAVDIR
fi

ksminstcmd="${CANDLE_HOME}/${TEMSARCH}/ms/bin/ksminst"
$ksminstcmd -f  -v 610 -e ${KSM_TEMP_DIR} >&2 || fail
$ksminstcmd -f  -v 610 -s ${KSM_TEMP_DIR} >&2 || fail
rcline=`tail -1 $CANDLE_HOME/logs/ksminst.log`
rc=`echo "$rcline" | sed 's/Exiting with rc <\(.*\)>/\1/'`
if [ "$rc" = "0" ]; then
    # On 6.2FP1 and later we can load support without restarting the TEMS
    if [ "$TEMSVRMF" -ge 06200100 -a -n "$HUB_TEMS_HOST" ]; then
        ${CANDLE_HOME}/bin/tacmd refreshCatalog -s ${TEMSNAME} || fail
    elif [ -z "$NO_RESTART_TEMS" ]; then
        echo Loading TEMS support without restart requires 6.2 Fixpack 1 or
        echo higher and HUB TEMS information passed via -h, -u, and -p.
        echo Restarting TEMS to activate support.
        $CANDLE_HOME/bin/CandleServer stop $TEMSNAME
        cd /
        $CANDLE_HOME/bin/CandleServer start $TEMSNAME || fail
        cd $SAVDIR
    fi
else
    echo "$ksminstcmd failed with return code $rc."
    fail
fi

rm -rf ${KSM_TEMP_DIR}

if [ -d "${CANDLE_HOME}/tables/cicatrsq/TECLIB" ]; then
cp ./ira/agent/common/k${PRODUCT_LOWER}.baroc ${CANDLE_HOME}/tables/cicatrsq/TECLIB/k${PRODUCT_LOWER}.baroc || fail
fi
if [ -d "${CANDLE_HOME}/tables/${TEMSNAME}/TECLIB" ]; then
cp ./ira/agent/common/k${PRODUCT_LOWER}.baroc ${CANDLE_HOME}/tables/${TEMSNAME}/TECLIB/k${PRODUCT_LOWER}.baroc || fail
fi

makedir "${CANDLE_HOME}/tables/cicatrsq/OSLC/xml" || fail
cp ./ira/agent/common/kaioslc.xml ${CANDLE_HOME}/tables/cicatrsq/OSLC/xml/kaioslc.xml || fail

cp ./ira/agent/common/${PRODUCT_LOWER}tms.ver ${CANDLE_HOME}/registry/ || fail
addInstallDateToVerFile $CANDLE_HOME/registry/${PRODUCT_LOWER}tms.ver
echo "Install of K${PRODUCT_CODE} TEMS support successful." 
