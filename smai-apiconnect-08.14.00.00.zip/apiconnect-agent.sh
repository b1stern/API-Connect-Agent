#!/bin/sh
#
# ****************************************************************************
# * Licensed Materials - Property of IBM
# *
# * OCO Source Materials - IBM Confidential
# * 5724-C04
# *
# * Copyright IBM Corporation 2007-2014 All Rights Reserved
# *
# * The source code for this program is not published or other-
# * wise divested of its trade secrets, irrespective of what has
# * been deposited with the U.S. Copyright Office.
# *****************************************************************************
#

SMAI_MAINCMD=`basename $0`
SMAI_PC=ai
SMAI_DESC="Monitoring Agent for APIConnect"
SMAI_ISMI=NO
SMAI_PRECONF=NO
SMAI_ALLOWCONF=YES
SMAI_PKG=smai-apiconnect
export SMAI_MAINCMD SMAI_PC SMAI_DESC SMAI_ISMI SMAI_PRECONF SMAI_ALLOWCONF SMAI_PKG

`dirname $0`/smai-agent.sh "$@"
