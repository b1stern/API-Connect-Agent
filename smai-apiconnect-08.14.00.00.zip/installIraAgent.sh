#!/bin/sh
# ----------------------------------------------------------------
# Monitoring Agent for APIConnect
# Version 814
# Agent Installation Script for Unix
#
# Licensed Materials - Property of IBM
# Copyright IBM Corp. , 2017. All Rights Reserved
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
# This file was created by IBM Agent Builder
# Version 6.3.4
#	Agent Builder Common.v6.3.4 201703151048
#	IBM Tivoli Monitoring Agent Generator.v6.3.4 201703151048
#	IBM Agent Builder UI.v6.3.4 201703151048
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.4 201703151048
#	Agent Builder CIM Data Provider.v6.3.4 201703151048
#	Agent Builder Custom Data Provider.v6.3.4 201703151048
#	Agent Builder HTTP Data Provider.v6.3.4 201703151048
#	Agent Builder ICMP Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.4 201703151048
#	Agent Builder Log Data Provider.v6.3.4 201703151048
#	Agent Builder SNMP Data Provider.v6.3.4 201703151048
#	Agent Builder WMI Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.4 201703151048
#	Agent Builder Dashboard Support.v6.3.4 201703151048
#	IBM Tivoli Monitoring Remote Deploy.v6.3.4 201703151048
#	IBM Tivoli Omnibus.v6.3.4 201703151048
# ----------------------------------------------------------------
usage()
{
    echo "Usage ./installIraAgent.sh [source directory] <ITM Install Directory> [-a architecture]"
    echo "or    <source directory>/installIraAgent.sh <source directory> <ITM Install Directory> [-a architecture]"
    exit 1
}

fail()
{
    echo "Installation failed.  Please see the log in ${CANDLE_HOME}/logs/k${PRODUCT_LOWER}install.log"
    exit 1
}

gskInstallDir()
{
    ARCHTYPE=`echo $ARCH | sed 's/^\([a-z]*\)[0-9]*/\1/'`
    BITS=`echo $ARCH | sed 's/^.*\([0-9]\)$/\1/'`
    if [ "$BITS" = "6" ]; then
        BITSEXT=64
    else
        unset BITSEXT
    fi

    PATH="${PATH}":/usr/sbin:/sbin export PATH
    case $ARCHTYPE in
    aix)
        if [ "$BITS" = "3" ]; then
            pkgName=gskta.rte
        else
            pkgName=gsksa.rte
        fi
        gskitDirs=`lslpp -f $pkgName|grep copyright|head -1`
        ;;
    hp|hpi)
        pkgName=gsk7bas${BITSEXT}
        gskitDirs=`swlist -l file $pkgName 2>&1|grep copyright|head -1`
        ;;
    li)
        ## If this system uses the old libstdc++, we need to search for a slightly different
        ## package name
        if [ -f /usr/lib/libstdc++.so.5 ]
        then
            pkgName=gsk7bas${BITSEXT}
        elif [ -f /usr/lib/libstdc++-libc6.2-2.so.3 ]
        then
            pkgName=gsk7bas_295
        fi

        # List the directories/files in the rpm package.  /copyright should always be there,
        # ie, /usr/local/ibm/gsk7/copyright
        gskitDirs=`rpm -ql $pkgName|grep copyright|head -1`
        ;;
    lia|lpp|ls|lx)
        pkgName=gsk7bas${BITSEXT}
        gskitDirs=`rpm -ql $pkgName|grep copyright|head -1`
        ;;
    sol)
        pkgName=gsk7bas${BITSEXT}
        gskitDirs=`pkgchk -v $pkgName 2>&1 |grep copyright|head -1`
        ;;
    esac

    GSKDIR=`dirname $gskitDirs`
}

# Get the list of lib architectures that will work for an agent of the
# specified architecture.  The agent's own architecture is the usual
# answer, but there can be others as well.
getLibArchList()
{
    case $1 in
        lia266)
            echo lia266 lia246
            ;;
        ls3243)
            echo ls3243 ls3263
            ;;
        ls3246)
            echo ls3246 ls3266
            ;;
        aix526)
            echo aix526 aix536
            ;;
        aix523)
            echo aix523 aix533
            ;;
        *)
            echo $1
            ;;
    esac
}

makedir()
{
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
    fi
}

addInstallDateToVerFile()
{
    VERARCH=`uname -a | grep "SunOS"`
    if [ $? -eq 0 ]; then
        epochTime=`nawk 'BEGIN{print srand()}'`
    else
        epochTime=`date +%s`
    fi
    echo "installDate = root|${epochTime}000|" >> $1
}

unset ARCH
unset REMOTE_DEPLOY
unset CDPATH
if [ "$#" -ge "2" ]; then
    # At least 2 arguments
    TEST=`echo $2 | cut -c1`
    if [ "$TEST" = "-" ]; then
        # Second option is a switch
        # We'll handle those later
        CANDLE_HOME="$1"
        shift
    else
        # First 2 arguments are the source dir
        # and candle home
        SRC_DIR="$1"
        CANDLE_HOME="$2"
        shift
        shift
    fi
elif [ "$#" -eq "1" ]; then
    # Only one argument -- it's candle home
    CANDLE_HOME="$1"
else
    # Not the right number of arguments
    usage
fi
# Now, we'll handle any switches
# The following switches are supported
# -r -a <arch>
# You can't use -r and -a together
while getopts "ra:" opt;
do
case $opt in
r)
    # Remote Deploy Flag
    if [ "$ARCH" =  "" ]; then
        REMOTE_DEPLOY=true
    else
        echo "-r and -a cannot be used together"
        usage
    fi
    ;;
a)
    # Arch
    ARCH=$OPTARG
    if [ "$REMOTE_DEPLOY" = "true" ]; then
        echo "-r and -a cannot be used together"
        usage
    fi
    ;;
*)
    # Invalid option
    usage
    ;;
esac
done

if [ -n "$SRC_DIR" ]; then
    cd "$SRC_DIR"
fi

if [ -f "${CANDLE_HOME}/config/.global.environment" ]; then
    ITM_ENV=false
    if [ -f "${CANDLE_HOME}/bin/agent.sh" ]; then
        JAVALESS_ENV=true
        MICRO_ENV=false
    else
        JAVALESS_ENV=false
        MICRO_ENV=true
    fi
else
    ITM_ENV=true
    JAVALESS_ENV=false
    MICRO_ENV=false
fi

if [ $JAVALESS_ENV = true ]; then
    # Make sure no installed agent with this agent's name has a different product code.
    if [ -f "${CANDLE_HOME}/bin/apiconnect-agent.sh" ]; then
        existingPC=`grep -h "SMAI_PC=" "${CANDLE_HOME}/bin/apiconnect-agent.sh"`
        if [ $? = 0 -a "$existingPC" != "SMAI_PC=ai" ]; then
            echo "Previously installed agent script ${CANDLE_HOME}/bin/apiconnect-agent.sh contains $existingPC."
            echo "   The script name matches this agent's name, but the product code does not belong to this agent."
            echo "   Use a unique product code and agent service name to avoid conflicts."
            exit 2
        fi
    fi

    # Make sure no installed agent with this agent's product code has a different name.
    existingScript=`grep -l "SMAI_PC=ai" ${CANDLE_HOME}/bin/*-agent.sh|grep -v "/apiconnect-agent.sh"`
    if [ $? = 0 ]; then
        echo "Previously installed agent script $existingScript contains SMAI_PC=ai."
        echo "   That is this agent's product code, but the script name does not match this agent's name."
        echo "   Use a unique product code and name in an agent to avoid conflicts."
        echo "   The script name is derived from the agent's service name."
        exit 2
    fi
fi

PRODUCT_CODE=ai
PRODUCT_LOWER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:upper:]' '[:lower:]')`
PRODUCT_UPPER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:lower:]' '[:upper:]')`
if [ -z "$CANDLE_HOME"  ]; then
    usage
fi
if [ ! -d "${CANDLE_HOME}/logs" ]; then
    mkdir -p "${CANDLE_HOME}/logs"
fi
exec 2> ${CANDLE_HOME}/logs/k${PRODUCT_LOWER}install.log
set -x
echo "# ----------------------------------------------------------------
# Monitoring Agent for APIConnect
# Version 814
# kAI Agent Installation Log
#
# Licensed Materials - Property of IBM
# Copyright IBM Corp. , 2017. All Rights Reserved
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
# This file was created by IBM Agent Builder
# Version 6.3.4
#	Agent Builder Common.v6.3.4 201703151048
#	IBM Tivoli Monitoring Agent Generator.v6.3.4 201703151048
#	IBM Agent Builder UI.v6.3.4 201703151048
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.4 201703151048
#	Agent Builder CIM Data Provider.v6.3.4 201703151048
#	Agent Builder Custom Data Provider.v6.3.4 201703151048
#	Agent Builder HTTP Data Provider.v6.3.4 201703151048
#	Agent Builder ICMP Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.4 201703151048
#	Agent Builder Log Data Provider.v6.3.4 201703151048
#	Agent Builder SNMP Data Provider.v6.3.4 201703151048
#	Agent Builder WMI Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.4 201703151048
#	Agent Builder Dashboard Support.v6.3.4 201703151048
#	IBM Tivoli Monitoring Remote Deploy.v6.3.4 201703151048
#	IBM Tivoli Omnibus.v6.3.4 201703151048
# ----------------------------------------------------------------
">> ${CANDLE_HOME}/logs/k${PRODUCT_LOWER}install.log

if [ ! -d "${CANDLE_HOME}/tmaitm6" ]; then
    echo No Tivoli Enterprise Monitoring Agent is found in ${CANDLE_HOME}.
    echo Please specify the correct location of your ITM installation.
    exit 1
fi
if [ -z "$ARCH"  ]; then
    if [ ! -d "${CANDLE_HOME}/tmp" ]; then
        mkdir -p "${CANDLE_HOME}/tmp" || fail
        chmod 775 "${CANDLE_HOME}/tmp"
    fi
    if [ $JAVALESS_ENV = true ]; then
        GETARCH_SCRIPT="getarch.sh"
    else
        GETARCH_SCRIPT="getarch.ksh"
    fi
    cp "${GETARCH_SCRIPT}" "${CANDLE_HOME}/tmp/${PRODUCT_LOWER}_${GETARCH_SCRIPT}" || fail
    chmod u+x "${CANDLE_HOME}/tmp/${PRODUCT_LOWER}_${GETARCH_SCRIPT}" || fail
    ARCH=`"${CANDLE_HOME}/tmp/${PRODUCT_LOWER}_${GETARCH_SCRIPT}" "$CANDLE_HOME"`
    RC=$?
    rm -f "${CANDLE_HOME}/tmp/${PRODUCT_LOWER}_${GETARCH_SCRIPT}"
    if [ $RC -ne 0 -o "$ARCH" = "" ]; then
        echo "Could not determine system architecture."
        echo "The ITM installation in $CANDLE_HOME is probably missing or incomplete."
        exit 1
    fi
    if [ "$ARCH" = "UNSUPPORTED" ]; then
        echo "Unsupported or unrecognized system architecture."
        echo "You can override this by specifying an architecture on the command line."
        exit 1
    fi
fi

VALID_ARCH_LIST=`getLibArchList ${ARCH}`
# For service, get the contents of tmaitm6 into the log.
ls -l "${CANDLE_HOME}/tmaitm6" >&2

for CANDIDATE_LIB_ARCH in ${VALID_ARCH_LIST}
do
    if [ -d "${CANDLE_HOME}/tmaitm6/${CANDIDATE_LIB_ARCH}/ax" -a -d "${CANDLE_HOME}/tmaitm6/${CANDIDATE_LIB_ARCH}/lib" ]; then
        LIB_ARCH=${CANDIDATE_LIB_ARCH}
        break
    fi
done
if [ -z "${LIB_ARCH}" ]; then
    echo "The supporting libraries for architecture ${ARCH} are not present in"
    echo "${CANDLE_HOME}/tmaitm6/${ARCH}/lib.  The agent can not be installed."
    exit 1
fi

if [ -f "${CANDLE_HOME}/registry/ax${ARCH}.ver" ]; then
    AXVER="${CANDLE_HOME}/registry/ax${ARCH}.ver"
elif [ -f "${CANDLE_HOME}/registry/ax${LIB_ARCH}.ver" ]; then
    AXVER="${CANDLE_HOME}/registry/ax${LIB_ARCH}.ver"
else
    AXVER=`ls -1 "${CANDLE_HOME}"/registry/ax*.ver | head -1`
fi
if [ -z "${AXVER}" ]; then
    echo No AX version file found, can not install.
    exit 1
fi
AXVRMF=`egrep "^VRMF[ ]*=" "${AXVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${AXVRMF}" -lt "06210000" ]; then
    echo This agent requires ITM version 06210000 \(6.2.1\) or higher to work correctly.
    echo The ITM installation in "${CANDLE_HOME}" is version ${AXVRMF},
    echo thus the agent can not install.
    exit 1
fi

echo "Installing k$PRODUCT_CODE ....."
# It's ok if this fails-- agent is not installed or not running
${CANDLE_HOME}/bin/itmcmd agent stop ${PRODUCT_CODE}
if [ $? -eq 0 ]; then
    AGENT_STOPPED=y
else
    AGENT_STOPPED=n
fi

SELF_DESCRIBING=true
if [ ! -d "support" ]
then
    SELF_DESCRIBING=false
fi
CURRENT=`pwd`
makedir "${CANDLE_HOME}/${ARCH}" || fail
cd $CANDLE_HOME/$ARCH || fail
makedir $PRODUCT_LOWER || fail
cd $PRODUCT_LOWER || fail
makedir bin || fail
makedir hist || fail
makedir lib || fail
makedir tables || fail
makedir tables/ATTRLIB || fail
if [ "$SELF_DESCRIBING" = "true" ]
then
    makedir support || fail
    chmod 775 support
fi
cd "$CURRENT" || fail
PRODUCT_HOME=$CANDLE_HOME/$ARCH/$PRODUCT_LOWER
chmod 775 "$PRODUCT_HOME/bin"
chmod 775 "$PRODUCT_HOME/hist"
chmod 775 "$PRODUCT_HOME/lib"
chmod 775 "$PRODUCT_HOME/tables"
chmod 775 "$PRODUCT_HOME/tables/ATTRLIB"
# copy the install files 
cp ./ira/agent/common/k${PRODUCT_LOWER}.atr  $PRODUCT_HOME/tables/ATTRLIB/k${PRODUCT_LOWER}.atr  || fail
chmod o+r "$PRODUCT_HOME/tables/ATTRLIB/k${PRODUCT_LOWER}.atr"  || fail
sed -e "s/INTERP/$ARCH/g" ./ira/agent/$ARCH/k${PRODUCT_LOWER}.ref > $PRODUCT_HOME/bin/k${PRODUCT_LOWER}.ref  || fail
JRVER=`/bin/ls -1 "${CANDLE_HOME}"/registry/jr*.ver | head -1`
JRARCH=`basename $JRVER | sed 's/jr\(.*\)\.ver/\1/'`
INENV="./ira/agent/${ARCH}/k${PRODUCT_LOWER}env"
OUTENV="${CANDLE_HOME}/config/.ConfigData/k${PRODUCT_LOWER}env"
if [ $ITM_ENV = true ]; then
    if [ ! -f "$OUTENV" ]; then
        cp "${INENV}" "${OUTENV}" || fail
        chmod 666 "${OUTENV}"|| fail
        OLDIFS="$IFS"
        IFS="|"
        while read ENVARCH KEY VAL
        do
            if [ "$ENVARCH" = "default" ]
            then
                IFS="$OLDIFS"

                LINE="${ARCH}|${KEY}|"
                if [ -n "$VAL" ]
                then
                    LINE="${LINE}${VAL}|"
                else
                    case "$KEY" in
                    ARCHITECTURE)   NEWVAL="tmaitm6/${LIB_ARCH}";;
                    BINARCH)        NEWVAL="${ARCH}";;
                    CANDLEHOME)     NEWVAL="${CANDLE_HOME}";;
                    HOSTNAME)       NEWVAL="`hostname`";;
                    JAVAHOME)       NEWVAL="${CANDLE_HOME}/JRE/${JRARCH}";;
                    *)              unset NEWVAL;;
                    esac

                    LINE="${LINE}${NEWVAL}|"
                fi

            echo $LINE >> "${OUTENV}"
            IFS="|"
        fi
    done < "${INENV}"
    IFS="$OLDIFS"
    if [ -f ${CANDLE_HOME}/config/gsKit.config ]; then
        ARCHBITS=`echo ${ARCH} | sed 's/^.*\([0-9]\)$/\1/'`
        if [ "${ARCHBITS}" = "6" ]; then
            GSKTAG=GskitInstallDir_64
        else
            GSKTAG=GskitInstallDir
        fi
        GSKDIR=`egrep "^${GSKTAG}" ${CANDLE_HOME}/config/gsKit.config | awk -F= '{print $2}'`
    else
        gskInstallDir
    fi
    echo "${ARCH}|ICCRTE_DIR|${GSKDIR}|" >> "${OUTENV}"
    else
        touch $OUTENV
    fi
fi
cp ./ira/agent/common/k${PRODUCT_LOWER}.his  $PRODUCT_HOME/hist/.  || fail
chmod o+r "$PRODUCT_HOME/hist/k${PRODUCT_LOWER}.his" || fail
cp ./ira/agent/$ARCH/${PRODUCT_LOWER}.rc $CANDLE_HOME/config/.${PRODUCT_LOWER}.rc  || fail
chmod 664 $CANDLE_HOME/config/.${PRODUCT_LOWER}.rc || fail
if [ ! -f $CANDLE_HOME/config/${PRODUCT_LOWER}.ini ]; then
    if [ ! $JAVALESS_ENV = true ]; then
        # this is a fresh install in an ITM/Micro environment
        cp ./ira/agent/$ARCH/${PRODUCT_LOWER}.ini $CANDLE_HOME/config/.  || fail
        chmod 664 $CANDLE_HOME/config/${PRODUCT_LOWER}.ini || fail
    fi
else
    # upgrade case for ITM environment/Micro environment
    for CONFIG in $CANDLE_HOME/config/${PRODUCT_LOWER}.ini $CANDLE_HOME/config/${PRODUCT_LOWER}.config $CANDLE_HOME/config/${PRODUCT_LOWER}_*.config
    do
        if [ -f $CONFIG ]; then
            chmod 664 $CONFIG || fail
            ira/agent/$ARCH/txtsub -u ./ira/agent/$ARCH/${PRODUCT_LOWER}.ini $CONFIG
        fi
    done
fi
# Copy any tasks or other dependency files 
if [ "$SELF_DESCRIBING" = "true" ]
then
    if [ $JAVALESS_ENV = true ]; then
        cp "./support/k${PRODUCT_LOWER}_sda_8.1.4.0000.jar" "$PRODUCT_HOME/support/k${PRODUCT_LOWER}_sda_8.1.4.0000.jar" || fail
    else
        cp ./support/KAIMSMAN.txt $PRODUCT_HOME/support/KAIMSMAN.txt || fail
        cp ./support/KAIJSTMS.jar $PRODUCT_HOME/support/KAIJSTMS.jar || fail
        cp ./support/KAIJSTPS.jar $PRODUCT_HOME/support/KAIJSTPS.jar || fail
        cp ./support/KAIJSTPW.jar $PRODUCT_HOME/support/KAIJSTPW.jar || fail
    fi
fi
cp ./ira/agent/$ARCH/queryIRA $PRODUCT_HOME/bin/k${PRODUCT_LOWER}agent || fail
if [ -f "./ira/agent/common/KAIAGENT0801.SYS2" ]; then
    cp ./ira/agent/common/KAIAGENT0801.SYS2 $PRODUCT_HOME/bin/KAIAGENT0801.SYS2|| fail
fi

echo "copying agent config files now...."
cp ./ira/agent/common/agentConfig/${PRODUCT_LOWER}_dd*.xml $PRODUCT_HOME/bin  || fail
cp ./ira/agent/common/agentConfig/${PRODUCT_LOWER}_dd*.properties $PRODUCT_HOME/bin  || fail
cp ./ira/agent/common/agentConfig/${PRODUCT_LOWER}_dd*.xml $CANDLE_HOME/config/. || fail
cp ./ira/agent/common/agentConfig/${PRODUCT_LOWER}_dd*.properties $CANDLE_HOME/config/. || fail
if [ ! -d "${CANDLE_HOME}/samples" ]; then
    mkdir "${CANDLE_HOME}/samples"
fi
cp "./ira/agent/common/agentConfig/samples/UNIX/apiconnect_silent_config.txt" "${CANDLE_HOME}/samples" || fail
cp ./ira/agent/$ARCH/*_config.ini $CANDLE_HOME/config/. || fail
chmod 664 $CANDLE_HOME/config/k${PRODUCT_LOWER}_config.ini || fail
grep "^${PRODUCT_LOWER}=" "$CANDLE_HOME/config/multiInstBPPC.properties" >/dev/null 2>/dev/null
if [ $? = 0 ]; then
    new=`sed /^${PRODUCT_LOWER}=/d < "$CANDLE_HOME/config/multiInstBPPC.properties"`
    echo "$new" > "$CANDLE_HOME/config/multiInstBPPC.properties" || fail
fi

if [ $MICRO_ENV = true ]; then
    # create the start script for the agent
    sed ' 
        s/\$PRODUCTDESC\$/'\""Monitoring Agent for APIConnect"\"'/g
        s/\$PRODUCTCODE\$/ai/g
        s/\$PRODUCTSTOPSIG\$/15/g' ./ira/agent/common/.agent.tmpl > ${CANDLE_HOME}/bin/.agent.ai
    chmod +x ${CANDLE_HOME}/bin/.agent.ai
fi
if [ $JAVALESS_ENV = true ]; then
    cp ./apiconnect-agent.sh ${CANDLE_HOME}/bin/apiconnect-agent.sh
    chmod +x ${CANDLE_HOME}/bin/apiconnect-agent.sh
fi
if [ $MICRO_ENV = true -o $JAVALESS_ENV = true ]; then
    AGENT_ENV_FILE="${CANDLE_HOME}/config/.${PRODUCT_LOWER}.environment"
    AGENT_PUBLIC_ENV_FILE="${CANDLE_HOME}/config/${PRODUCT_LOWER}.environment"
    if [ -f ${AGENT_ENV_FILE} ]; then
        AGENT_UPGRADE=true
    else
        AGENT_UPGRADE=false
    fi
    # Transform the .ini file from the agent installation package to create the .pc.environment file.
    # Replace common installer variables with micro agent/APM variables.
    # Need default values for CT_CMSLIST and KDC_FAMILIES so no config step is needed.
    sed ' 

        s/\$CANDLEHOME\$/\${CANDLEHOME}/g
        s/\$COMMENT\$/\#/g
        s/\$CLUSTERFLAG\$/\#/g
        s/\$CLUSTERNAME\$//g
        s/\$BINARCH\$/\${PRODUCTARCH}/g
        s/\$PRODUCTCODE\$/\${PRODUCTCODE}/g
        s/\$ARCHITECTURE\$/tmaitm6\/\${TEMAARCH}/g
        s/\$RUNNINGHOSTNAME\$/\${RUNNINGHOSTNAME}/g
        s/\$HOSTNAME\$/\${RUNNINGHOSTNAME}/g
        s/\$JAVAHOME\$/\${CANDLEHOME}\/JRE\/\${JAVAARCH}/g
        s/\$KDC_PARTITIONNAME\$//g
        s/\$ICCRTE_DIR\$/\${CANDLEHOME}\/\${GSKARCH}\/gs/g
        s/\$GSKLIB\$/\${GSKLIB}/g
        s/\$INSTANCE_ARG\$/${INSTANCENAME}/g
        s/\$INSTANCE\$/${INSTANCENAME}/g
        s/^CT_CMSLIST.*$/CT_CMSLIST=""/g
        s/^KDC_FAMILIES.*$/KDC_FAMILIES=ip.pipe port:1918 ip use:n ip.spipe use:n sna use:n/g
        s/\$RUNNINGHOSTNAME\$/\${RUNNINGHOSTNAME}/g
        s/^LD_LIBRARY_PATH=\(.*$\)/LD_LIBRARY_PATH=\${CANDLEHOME}\/\${GSKARCH}\/gs\/\${GSKLIB}:\1/g
        s/^LIBPATH=\(.*$\)/LIBPATH=\${CANDLEHOME}\/\${GSKARCH}\/gs\/\${GSKLIB}:\1/g
        s/^SHLIB_PATH=\(.*$\)/SHLIB_PATH=\${CANDLEHOME}\/\${GSKARCH}\/gs\/\${GSKLIB}:\1/g'    ./ira/agent/$ARCH/${PRODUCT_LOWER}.ini > "${AGENT_ENV_FILE}"
    # Replace the .pc.environment file for new install or upgrade.
    # Customizations belong in pc.environment which will not be overwritten.
    if [ "${AGENT_UPGRADE}" == "false" ]; then
        # Remove the ini file if it exists. The ini files are not used in this environment.
        rm -f ${CANDLE_HOME}/config/${PRODUCT_LOWER}.ini
    fi
    # Copy the public environment file - the one that the user should edit. Not copied if it exists, the user may have made changes.
    if [ ! -f ${AGENT_PUBLIC_ENV_FILE} ]; then
        cp ./ira/agent/$ARCH/${PRODUCT_LOWER}.environment ${AGENT_PUBLIC_ENV_FILE}
    fi
fi

# create the directory which contains user-provided configuration 
# most of the config is in localconfig/<pc> 
# workspaces for the service console are in localconfig/<pc>/html 
makedir "$CANDLE_HOME/localconfig/ai/html" || fail

# copy the user-provided configuration files for situations, traps and EIF events if they exist  
if [ -f ./ira/agent/common/ai_situations.xml ] ; then
    cp ./ira/agent/common/ai_situations.xml ${CANDLE_HOME}/localconfig/ai/.
fi
if [ -f ./ira/agent/common/ai_trapcnfg.xml ] ; then
    cp ./ira/agent/common/ai_trapcnfg.xml ${CANDLE_HOME}/localconfig/ai/.
fi
if [ -f ./ira/agent/common/ai_cnfglist.xml ] ; then
    cp ./ira/agent/common/ai_cnfglist.xml ${CANDLE_HOME}/localconfig/ai/.
fi
if [ -f ./ira/agent/common/ai_eventmap.map ] ; then
    cp ./ira/agent/common/ai_eventmap.map ${CANDLE_HOME}/localconfig/ai/.
fi
if [ -f ./ira/agent/common/ai_eventdest.xml ] ; then
    cp ./ira/agent/common/ai_eventdest.xml ${CANDLE_HOME}/localconfig/ai/.
fi

if [ -f ./ira/agent/common/${PRODUCT_LOWER}_default.xml ]; then
    if [ ! -f $CANDLE_HOME/config/CAP/${PRODUCT_LOWER}_default.xml ]; then
        makedir "$CANDLE_HOME/config/CAP" || fail
        cat ./ira/agent/common/${PRODUCT_LOWER}_default.xml | tr -d '\r' > $CANDLE_HOME/config/CAP/k${PRODUCT_LOWER}_default.xml  || fail
    fi
fi

# If there's already an entry for this PC, comment it out if it's wrong
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    # There's already an entry for this product code-- 
    # If it differs from ours, comment it out and add our new one
    awk -F\| '{if ($1 == "ai" && $2 != "Monitoring Agent for APIConnect") 
                { printf("#%s\n",$0) }
               else
                { print $0} }' "$CANDLE_HOME/registry/proddsc.tbl" > "$CANDLE_HOME/registry/proddsc.tbl.$$" || fail
    mv -f "$CANDLE_HOME/registry/proddsc.tbl.$$" "$CANDLE_HOME/registry/proddsc.tbl" || fail
fi
# We may have commented some out, but one might have been right, so only add if we need to
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    cat ./ira/agent/common/proddsc.tbl >> $CANDLE_HOME/registry/proddsc.tbl  || fail
fi
if [ $JAVALESS_ENV = true ]; then
    SOURCE_VER_FILE=${PRODUCT_LOWER}_javaless.ver
else
    SOURCE_VER_FILE=${PRODUCT_LOWER}.ver
fi
sed "s/%LIBARCH%/${LIB_ARCH}/g" ./ira/agent/$ARCH/${SOURCE_VER_FILE} > $CANDLE_HOME/registry/${PRODUCT_LOWER}${ARCH}.ver  || fail
addInstallDateToVerFile $CANDLE_HOME/registry/${PRODUCT_LOWER}${ARCH}.ver
chmod 644 $CANDLE_HOME/registry/${PRODUCT_LOWER}${ARCH}.ver  || fail


chmod +rx ${PRODUCT_HOME}/bin/* 

if [ -f "$CANDLE_HOME/bin/syncLocalConfDirs.sh" ]; then
    "$CANDLE_HOME/bin/syncLocalConfDirs.sh" >&2
    if [ -d "$CANDLE_HOME/$ARCH/${PRODUCT_LOWER}/tables/EIFLIB" ]; then
        cp ./ira/agent/common/k${PRODUCT_LOWER}.baroc  $CANDLE_HOME/$ARCH/${PRODUCT_LOWER}/tables/EIFLIB/k${PRODUCT_LOWER}.baroc  || fail
    else
        echo No EIFLIB created by syncLocalConfDirs.sh, not copying the baroc file
    fi
fi

if [ $MICRO_ENV = true -o $JAVALESS_ENV = true ]; then
# agents may have custom configuration files. If they are part of the image, copy them.
    if [ -f ./ira/agent/common/ai.cfg ] ; then
        cp ./ira/agent/common/ai.cfg ${CANDLE_HOME}/config/.
        if [ "$AGENT_STOPPED" != "y" ]; then
            echo "attempting to start agent ${PRODUCT_CODE}"
            ${CANDLE_HOME}/bin/itmcmd agent start ${PRODUCT_CODE}
        fi
    else
        if [ "$AGENT_STOPPED" != "y" ]; then
            echo "No configuration file provided for agent ${PRODUCT_CODE} which requires agent configuration information, not starting the agent."
        fi
    fi

    ${CANDLE_HOME}/bin/UpdateAutoRun.sh -h ${CANDLE_HOME}
fi
if [ "$AGENT_STOPPED" = "y" ]; then
    SAVDIR=`pwd`
    cd /
    ${CANDLE_HOME}/bin/itmcmd agent start ${PRODUCT_CODE}
    cd $SAVDIR
fi

echo "Install of K${PRODUCT_CODE} Agent successful."
if [ ! -f $CANDLE_HOME/bin/smai-agent.sh ]; then 
    if [ $ITM_ENV = true ]; then
        echo "To configure the agent, run:"
        echo "    ${CANDLE_HOME}/bin/itmcmd config -A ${PRODUCT_CODE}"
    fi
    echo "To start the agent, run:"
    echo "    ${CANDLE_HOME}/bin/itmcmd agent start ${PRODUCT_CODE}"
    echo "To stop the agent, run:"
    echo "    ${CANDLE_HOME}/bin/itmcmd agent stop ${PRODUCT_CODE}"
fi
